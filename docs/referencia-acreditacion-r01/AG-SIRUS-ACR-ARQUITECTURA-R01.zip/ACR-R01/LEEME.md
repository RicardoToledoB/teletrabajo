# Entrega R01
Leer primero ACR-INFORME-TECNICO.pdf y ACR-CONTROL-INTEGRIDAD.md. Modelo documental para auditoría; no ejecutar SQL ni colección sobre producción. Los contratos publicados están separados de los propuestos. No contiene datos de funcionarios.
