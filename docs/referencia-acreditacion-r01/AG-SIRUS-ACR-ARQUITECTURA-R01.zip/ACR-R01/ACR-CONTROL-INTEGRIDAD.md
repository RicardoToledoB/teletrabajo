# ACR R01 — Control de integridad documental
Estado: PREPARADO, no implementado ni aprobado por inspector.

- Tablas originales: 14
- Tablas modelo: 28
- Campos modelo: 316
- Relaciones internas: 48
- Referencias externas: 15
- Controles de formulario: 191
- Operaciones publicadas: 17
- Operaciones propuestas: 67
- Registros reales: 0

## Controles realizados
- 22 fichas extraídas; cada fila tiene destino o derivación explícita.
- Todos los destinos directos del mapa existen en diccionario.
- Toda referencia interna tiene tabla destino e ID.
- Referencias OpenAPI resueltas estructuralmente.
- Sin datos reales ni simulación de persistencia.

## Pendientes y límites
- SQL no ejecutado en PostgreSQL; tipos y nulabilidad propuestos, FK externa users pendiente.
- El SQL es un modelo de revisión, no una migración incremental.
- OpenAPI complementario es borrador: restricciones por operación, paginación, multipart, firmas, transiciones y cobertura de acciones especiales necesitan auditoría; no es contrato de producción.
- Postman contiene plantillas con valores nulos deliberados; completar payload válido, IDs y entorno; sin ejecución real.
- No se ha inspeccionado BD física, permisos ni fuente Angular actual.
- No se ha realizado aprobación independiente ni validación de conformidad normativa de bases futuras.

## Fuentes SHA-256
- Propuesta_Integral_Acreditacion_Ley_Medica_Completa_Pantallas_y_Formularios(7).docx: 8818e8b1bc11883cd909b42811f5bab170ef100bf588f297a154e6eb6919718f
- Markdown pegado(20261124-184501).md: 2250579cf63fa72cd462a25e933c18f68524a9e3e4f61dede28610d289ba3e7c
- AG-GP-ACR-SWAGGER-001-INFORME(4).md: d728f7ccc699b4912005a2fc02ac792a6cc6babc561568d13475fffdba240d7d
- Texto pegado(20261124-183540).txt: ab665dcc1f432ab928364bd51a7b4915d1b65f446ecfa1ab3fdfbac74bfd4778